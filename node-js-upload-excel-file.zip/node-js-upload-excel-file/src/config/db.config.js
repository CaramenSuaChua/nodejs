module.exports = {
  HOST: "mongodb+srv://ngodung:ngodung3042000@cluster0.maaubuy.mongodb.net/?retryWrites=true&w=majority",
  USER: "root",
  PASSWORD: "",
  DB: "testdb",
  dialect: "mysql",
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
};